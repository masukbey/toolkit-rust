This release updates the `tendermint-proto` crate to v0.30.0.

At the moment, only the Tendermint Protobuf definitions for CometBFT 0.37 are exported
and supported. In the future, side-by-side support for 0.34 and 0.37 definitions may be provided.
