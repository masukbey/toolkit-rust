- Update `tendermint-proto` to v0.30.0 ([\#64](https://github.com/cosmos/ibc-
  proto-rs/issues/64))