This release updates the `ibc-go` proto files from version `v5.0.0` to `v5.1.0`.

This includes the `memo` field in the following struct:

* `ibc.applications.transfer.v1 MsgTransfer`
* `ibc.applications.transfer.v2 FungibleTokenPacketData`

As well as the `sequence` field in:

* `ibc.applications.transfer.v1 MsgTransferResponse`
