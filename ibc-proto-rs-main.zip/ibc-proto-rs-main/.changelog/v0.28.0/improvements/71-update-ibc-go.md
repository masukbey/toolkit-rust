- Update `ibc-go` commit from `v5.0.0` to `v5.1.0`
([#71](https://github.com/cosmos/ibc-proto-rs/issues/71))