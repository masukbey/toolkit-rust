- Downgrade `borsh` version from `v0.10.0` to `v0.9`
  ([#106](https://github.com/cosmos/ibc-proto-rs/pull/104))