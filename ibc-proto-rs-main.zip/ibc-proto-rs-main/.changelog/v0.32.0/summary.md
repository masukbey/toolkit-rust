*June 14th, 2023*

This release updates the `ibc-go` proto files from version `v5.1.0` to `v6.2.0` which includes the ICA Protobuf definitions.

The version of `borsh` has been downgraded from `v0.10.0` to `v0.9` in order to match `near-sdk-rs` and Solana smart contract frame `anchor`.
