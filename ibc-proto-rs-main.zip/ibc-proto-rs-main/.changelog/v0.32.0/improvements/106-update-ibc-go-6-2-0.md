- Update `ibc-go` commit from `v5.1.0` to `v6.2.0`
  ([#106](https://github.com/cosmos/ibc-proto-rs/issues/106))