- Update `tonic` to 0.9 and re-generate the protos
  ([\#79](https://github.com/cosmos/ibc-proto-rs/issues/79))
