- Remove errors for `encode_vec` and `encode_length_delimited_vec` in
  `Protobuf` ([#73](https://github.com/cosmos/ibc-proto-rs/issues/73))
