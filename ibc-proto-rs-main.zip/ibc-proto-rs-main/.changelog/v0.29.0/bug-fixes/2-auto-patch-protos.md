- Automatically patch the generated Rust code for it to compile
  ([\#2](https://github.com/cosmos/ibc-proto-rs/issues/2))