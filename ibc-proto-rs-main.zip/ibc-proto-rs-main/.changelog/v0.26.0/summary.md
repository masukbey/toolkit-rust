*February 17, 2023*

This release updates tendermint protobuf defintions to `v0.29.0`.
