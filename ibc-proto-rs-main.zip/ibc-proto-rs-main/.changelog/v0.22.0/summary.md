This release updates the Cosmos SDK protobufs to v0.46.4.
