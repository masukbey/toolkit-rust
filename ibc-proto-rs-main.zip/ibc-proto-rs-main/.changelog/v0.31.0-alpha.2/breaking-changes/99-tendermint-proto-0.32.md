- Update `tendermint-proto` to v0.32.0
  ([\#99](https://github.com/cosmos/ibc-proto-rs/issues/99))
