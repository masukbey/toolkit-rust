This release adds `parity-scale-codec` and `borsh` serialize/deserialize for the `Any` type.
