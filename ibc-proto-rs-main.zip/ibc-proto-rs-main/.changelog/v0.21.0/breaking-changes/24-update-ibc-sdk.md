- Update protos to IBC-Go v5.0.0 and Cosmos SDK v0.46.1
  ([#24](https://github.com/cosmos/ibc-proto-rs/issues/24))