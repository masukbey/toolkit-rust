- Update tendermint-proto requirement from =0.23.9 to =0.25.0
  ([#26](https://github.com/cosmos/ibc-proto-rs/issues/26))