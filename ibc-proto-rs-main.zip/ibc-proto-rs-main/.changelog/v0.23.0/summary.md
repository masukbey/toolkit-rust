*November 29th, 2022*

This release updates the Tendermint Protobuf definitons to v0.27.0.
