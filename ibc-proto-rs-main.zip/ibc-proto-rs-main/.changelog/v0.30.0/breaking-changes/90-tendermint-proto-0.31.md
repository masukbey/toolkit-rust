- Update `tendermint-proto` to v0.31.x
  ([\#90](https://github.com/cosmos/ibc-proto-rs/pull/90))
