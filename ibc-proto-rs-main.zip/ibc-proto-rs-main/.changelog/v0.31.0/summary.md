*May 31st, 2023*

This is the final release of `ibc-proto` v0.31.0.

There are no changes from v0.31.0-alpha.2.

For the differences since v0.30.0, please see the changelog entries for v0.31.0-alpha.1 and v0.31.0-alpha.1.

> **Warning**
> This release removes support for `Serialize` and `Deserailize` trait impls being available in `no_std` context.
> See the release notes below and associated issues for more details.
