- Update to tendermint-proto 0.28 ([#45](https://github.com/cosmos/ibc-proto-
  rs/issues/45))